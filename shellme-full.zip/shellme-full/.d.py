import socket
import os
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('127.0.0.1', 5050))
data = os.system("dir")
s.send(data)
print(s.recv(1001))
s.close