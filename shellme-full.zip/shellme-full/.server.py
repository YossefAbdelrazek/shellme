import socket,os
import sys
import time
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
a = socket.gethostname()
b = socket.gethostbyname(a)
PORT = 5050
s.bind(('127.0.0.1',PORT))
s.listen(3)
os.system("clear")
mas8 = f"starting server TCP Connection {b}:{PORT}\n"
for shar8 in mas8:
    sys.stdout.write(shar8)
    sys.stdout.flush()
    time.sleep(0.03)
mas = "WATING FOR CONNECTION ..."
time.sleep(1.5)
for shar in mas:
    sys.stdout.write(shar)
    sys.stdout.flush()
    time.sleep(0.03)
s,a=s.accept()
mas2 = "\n* YOU HAVE IP CONNECED"
time.sleep(1.1)
for shar3 in mas2:
    sys.stdout.write(shar3)
    sys.stdout.flush()
    time.sleep(0.03)
mas3 = f"\n[*] Sending Stage (3405 bayts) to {a[0]}\n"
time.sleep(1)
for shar2 in mas3:
    sys.stdout.write(shar2)
    sys.stdout.flush()
    time.sleep(0.03)
mas4 = "* THE SISSON IS OPEN . . . . . . . . . . . . .\n"
for shar4 in mas4:
        sys.stdout.write(shar4)
        sys.stdout.flush()
        time.sleep(0.04)
        mas5 = "* STARTING THE SISSON . . . . . . . . . . . .\n"
for shar5 in mas5:
        sys.stdout.write(shar5)
        sys.stdout.flush()
        time.sleep(0.04)
while True:
   time.sleep(1)
   i=input(f"\033[1;34m<\033[1;31m{b}\033[1;34m>\033[1;33m{a[0]}\033[1;32m> ")
   #s.send(i.encode())
   if i == "close":
       print(f"==> {i} ")
       print("connection is done !")
       time.sleep(2)
       s.shutdown
   if i == "clear":
         print(f"==> {i}")
         os.system("cls")        
   else:
        print(f"==> {i}")
        print("the command is not found")

 

   